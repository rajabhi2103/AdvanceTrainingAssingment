package com.mycompany.dao;

import com.mycompany.domain.Product;

public class ProductManagementDAO {
	
	public void getAllProducts() {
	}
	public Product getProductById(String ID) {
		return null;
	}
	public  Product addProduct(Product product) {
		return null;
	}
	public  Product deleteProduct(String ID) {
		return null;
	}
	public  Product updateProduct(String ID, String name) {
		return null;
	}

}
